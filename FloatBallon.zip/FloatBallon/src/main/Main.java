package main;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;
import java.util.ArrayList;
import java.util.Random;

public class Main {

    private double strenght = 30;
    public Main () {
        JFrame jFrame  = new JFrame();
        Ambiente ambiente = new Ambiente();

      jFrame.addKeyListener(new KeyListener() {
          @Override
          public void keyTyped(KeyEvent e) {

          }

          @Override
          public void keyPressed(KeyEvent e) {
              if (e.getKeyCode() == KeyEvent.VK_LEFT)
                  ambiente.goToLeft();

              if (e.getKeyCode() == KeyEvent.VK_RIGHT)
                  ambiente.goToRight();

              if (e.getKeyCode() == KeyEvent.VK_DOWN)
                  ambiente.goToDown();

              if (e.getKeyCode() == KeyEvent.VK_UP)
                  ambiente.goToUp();

              if (e.getKeyCode() == KeyEvent.VK_SPACE)
                  ambiente.stopBallon ();

          }

          @Override
          public void keyReleased(KeyEvent e) {

          }
      });
        jFrame.setSize(new Dimension(1200,750));
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame.setLocationRelativeTo(null);
        jFrame.setVisible(true);
        jFrame.getContentPane().add(ambiente);
    }

    public static void main(String[] args) {
       new Main ();
    }

    enum Moving {
        ToLeft,
        ToRight,
        ToDown,
        ToUp,
        NoMove
    }

    class Ambiente extends JComponent{

        private Graphics2D graphics2D;
        private Point[][] ventilador_points = new Point[3][2];
        private Point[] ballon_points = new Point[2];
        private java.util.List<Point> clouds_position = new ArrayList<>();
        private Ellipse2D ballon = null;
        private Moving moving_x;
        private Moving moving_y;
        private  int cloud_y = 0;
        private int rotation = 0;
        private int translate_x = 0;
        private int translate_y = 0;
        float x = 500, y = 50;
        private boolean endGame = false;
        private final int STRENGHT = 30;

        public Ambiente () {
            moving_x = Moving.ToRight;
            moving_y = Moving.ToDown;
            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    while (true){
                        try{
                            Thread.sleep(1000/24);
                        }catch (Exception e) {

                        }
                        repaint();
                    }
                }
            });
            thread.start();
        }

        public void goToLeft () {
            translate_x -= STRENGHT;
        }
        public void goToRight () {
            translate_x += STRENGHT;
        }
        public void goToUp () {
            translate_y -= STRENGHT;
        }
        public void goToDown () {
            translate_y += STRENGHT;
        }

        @Override
        public void paint(Graphics g){
            super.paint(g);
            graphics2D = (Graphics2D) g;
            createAmbiente ();
        }

        private void createAmbiente (){
            graphics2D.setColor(new Color(24,89,147));
            graphics2D.fillRect(0,0,getWidth(),getHeight());
            createBallon ();
            AffineTransform affineTransform = graphics2D.getTransform();
            for (int i = 0; i < 4; i++) {
                graphics2D.translate(0,200);
                for (int j = 0; j < 2;j++) {
                    createCloud ();
                    graphics2D.translate(800,0);
                }
                graphics2D.translate(800 * (-2),0);
            }
            graphics2D.setTransform(affineTransform);
            createVentilador ();
            verifyColide ();
            for (int i = 0; i < 20; i++){
                createTriangles ();
                graphics2D.translate(60,0);
            }

        }
        public void stopBallon () {
           if (moving_x == Moving.NoMove &&
                   moving_x == moving_y ){
               moving_x = Moving.ToRight;
               moving_y = Moving.ToDown;
           }
           else
           moving_x = moving_y = Moving.NoMove;
       }
        private void createBallon () {

            float w = 90;
            float h = 90;
            final int strenght = 10;
            AffineTransform affineTransform = graphics2D.getTransform();
            graphics2D.setRenderingHint(RenderingHints.KEY_RENDERING,RenderingHints.VALUE_RENDER_QUALITY);
            graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
            if (x >= getWidth() && moving_x == Moving.ToRight)
                moving_x =Moving.ToLeft;
            if (x <=0 && moving_x == Moving.ToLeft)
                moving_x = Moving.ToRight;
            if (y >= getHeight() && moving_y == Moving.ToDown)
                moving_y =Moving.ToUp;
            if (y <= 0 && moving_y == Moving.ToUp)
                moving_y = Moving.ToDown;

            if(moving_x == Moving.ToRight)
                x += strenght;
            else if (moving_x == Moving.ToLeft)
                x -= strenght;

            if(moving_y == Moving.ToUp)
                y -= strenght;
            else if (moving_y == Moving.ToDown)
                y += strenght;
            Ellipse2D circle = new Ellipse2D.Float(x,y,w,h);
            ballon_points[0] = new Point((int)x,(int)y);
            ballon_points[1] = new Point((int)(x+w),(int)(y+h));

          /*  GeneralPath line = new GeneralPath();
            final float reducer = 20;
            line.moveTo(x = (float)(x + w/2.0), y= (y+h));
            line.lineTo(x = (float)(x - ((w/2.0)-reducer)), y= ((y+h/2)-reducer));
            line.lineTo(x = (x + (w-reducer)), y);
            line.lineTo(x = (float)(x - ((w/2.0))), y= (y-h/2));*/
            graphics2D.setColor(new Color(230,234,237));
            graphics2D.fill(circle);
//            graphics2D.fill(line);

            graphics2D.setTransform(affineTransform);
        }
        private void createCloud () {
            final float w = 50;
            final float h = 50;
            AffineTransform affineTransform = graphics2D.getTransform();
            graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            Ellipse2D[] clouds = {new Ellipse2D.Float(0,
                    cloud_y+20,w,h), new Ellipse2D.Float(w-30,
                    cloud_y,w,h),new Ellipse2D.Float(w-10,
                    cloud_y+20,w,h)};
            graphics2D.setPaint(new GradientPaint(0,30,new Color(225,225,225),
                    0,30,new Color(15,15,15)));
            for (Ellipse2D cloud : clouds)
                graphics2D.fill(cloud);

            if (!endGame)
                if (clouds[2].getY() > -800){
                    cloud_y -= 5;
                }else{
                    cloud_y = 0;
                }
            graphics2D.setTransform(affineTransform);
        }
        private void createVentilador () {
            AffineTransform affineTransform = graphics2D.getTransform();
            graphics2D.translate(translate_x,translate_y);
            if(!endGame)
            graphics2D.rotate(rotation,500+10,500);
            AffineTransform affineTransform2 = graphics2D.getTransform();
            graphics2D.rotate(90,500+10,500);
            graphics2D.setColor(new Color(24,24,24));
            for (int i = 0; i < 3; i++){
                Ellipse2D ventil = new Ellipse2D.Float(500,500,20,100);
                graphics2D.fill(ventil);
                ventilador_points[i][0] = new Point(translate_x+500-80,translate_y+500);
                ventilador_points[i][1] = new Point(translate_x+500+80,translate_y+500+100);
                graphics2D.rotate(90,500+10,500);
            }
            graphics2D.setTransform(affineTransform2);
            graphics2D.setTransform(affineTransform);
            rotation +=10;
        }
        private void showEndGame () {
            endGame = true;
           graphics2D.setColor(Color.RED);
           graphics2D.drawImage(new ImageIcon(getClass().getResource("/img/logo.png")).getImage(),
                   250,250,this);
        }
        private void verifyColide () {
           if (ballon_points[1].getY() >= getHeight()-50){
               showEndGame ();
               stopBallon();
           }else  if (ballon_points[0].getX() >= ventilador_points[0][0].getX() &&
                   ballon_points[1].getX()  <= ventilador_points[0][1].getX()
                   &&  ventilador_points[0][0].getY() >  ballon_points[1].getY()  ){
               moving_y = Moving.ToUp;

               final double ballonCenter_X = (ballon_points[1].getX() + ballon_points[0].getX())/2;
               final double ballonCenter_Y = (ballon_points[1].getY() + ballon_points[0].getY())/2;
               final double ventiladorCenter = ((ventilador_points[0][0].getX()+ventilador_points[0][1].getX())/2);
               if (ballonCenter_X > ventiladorCenter)
                   moving_x = Moving.ToRight;
               else if (ballonCenter_X == ventiladorCenter)
                   moving_x = Moving.NoMove;
               else
                   moving_x = Moving.ToLeft;
           }








        }
        private void createTriangles () {
            GeneralPath generalPath = new GeneralPath();
            generalPath.moveTo(0,getHeight());
            generalPath.lineTo(25,getHeight()-50);
            generalPath.lineTo(50,getHeight());
            generalPath.closePath();
            graphics2D.setColor(Color.RED);
            graphics2D.fill(generalPath);
        }
    }

}
